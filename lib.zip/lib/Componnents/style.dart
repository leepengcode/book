import 'package:flutter/material.dart';

TextStyle THeader() {
  return TextStyle(
    fontSize: 15,
    color: Colors.black,
    fontWeight: FontWeight.bold,
  );
}
